/** Automatically generated file. DO NOT MODIFY */
package org.apache.cordova;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}