﻿
var currentPromotionId = -1;
var currentPromotionAddId = -1;
var currentCategoryId = -1;
var currentShopId = -1;
var notifyId = -1;

var promotions = [];

var newPromotions = [];

var promotionsAdds = [];

var shops = [];

var partners = [];

var nearShops = [];

var categories = [];
for (var i = 1; i <= 6; i++) {
    categories[i + ""] = [];
}

var endUser = null;

var promotionsCode = [];

var bestView = [];

var bestBuy = [];

var plist = null;

var shopDis = [];

var group = new Array();